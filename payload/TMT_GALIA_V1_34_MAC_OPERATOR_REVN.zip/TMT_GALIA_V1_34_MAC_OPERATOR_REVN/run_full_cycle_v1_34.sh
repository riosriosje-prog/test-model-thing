#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3.13}"
ENVELOPE_ZIP="$ROOT/TMT_GALIA_V1_34_EXECUTION_ENVELOPE_REVI.zip"
EXPECTED_ENVELOPE_SHA256="11f6dddaae2441add80962f688411c4f2ec04148b0a444a46acd0b63030526f3"
WORK="${1:-$ROOT/work-v1_34}"
RESULTS="${2:-$ROOT/results-v1_34}"

# Never recursively delete caller-selected paths. Both WORK and RESULTS must be
# absent or empty real directories; symbolic links are refused.
for LABEL in WORK RESULTS; do
  if [ "$LABEL" = "WORK" ]; then
    TARGET="$WORK"
  else
    TARGET="$RESULTS"
  fi

  if [ -L "$TARGET" ]; then
    echo "BLOCKED: $LABEL path must not be a symbolic link" >&2
    exit 2
  fi

  if [ -e "$TARGET" ]; then
    test -d "$TARGET" || {
      echo "BLOCKED: $LABEL path exists and is not a directory" >&2
      exit 2
    }
    if [ -n "$(find "$TARGET" -mindepth 1 -maxdepth 1 -print -quit)" ]; then
      echo "BLOCKED: $LABEL directory is not empty; use a fresh directory" >&2
      exit 2
    fi
  else
    mkdir -p "$TARGET"
  fi
done

echo "[1/7] Verifying host"
test "$(uname -s)" = "Darwin" || { echo "BLOCKED: macOS required" >&2; exit 2; }
test "$(uname -m)" = "arm64" || { echo "BLOCKED: native arm64 required" >&2; exit 2; }
MACOS_VERSION="$(sw_vers -productVersion)"
MACOS_MAJOR="${MACOS_VERSION%%.*}"
test "$MACOS_MAJOR" -ge 14 || { echo "BLOCKED: macOS >=14 required" >&2; exit 2; }
command -v "$PYTHON_BIN" >/dev/null 2>&1 || {
  echo "BLOCKED: $PYTHON_BIN not found" >&2
  exit 2
}
"$PYTHON_BIN" - <<'PY'
import sys
assert (sys.version_info.major, sys.version_info.minor) == (3, 13), sys.version
print("OPERATOR_PYTHON_BINDING=PASS")
PY

echo "[2/7] Verifying bound envelope SHA-256 before extraction"
"$PYTHON_BIN" - "$ENVELOPE_ZIP" "$EXPECTED_ENVELOPE_SHA256" "$ROOT/OPERATOR_CONTRACT.json" <<'PY'
import hashlib, json, sys
from pathlib import Path

envelope=Path(sys.argv[1])
expected=sys.argv[2]
contract_path=Path(sys.argv[3])

if not envelope.is_file():
    raise SystemExit("BLOCKED: bound execution envelope missing")

actual=hashlib.sha256(envelope.read_bytes()).hexdigest()
if actual != expected:
    raise SystemExit(
        f"BLOCKED: execution envelope SHA-256 mismatch: expected={expected} actual={actual}"
    )

contract=json.loads(contract_path.read_text())
contract_expected=(contract.get("execution_envelope") or {}).get("sha256")
if contract_expected != expected:
    raise SystemExit("BLOCKED: operator contract envelope hash does not match embedded trust anchor")

print("OPERATOR_ENVELOPE_SHA256_GATE=PASS")
PY

echo "[3/7] Extracting execution envelope"
"$PYTHON_BIN" - "$ENVELOPE_ZIP" "$WORK" <<'PY'
import sys, zipfile
from pathlib import Path
src=Path(sys.argv[1]); dst=Path(sys.argv[2])
with zipfile.ZipFile(src) as z:
    z.extractall(dst)
PY

ENVROOT="$WORK/TMT_GALIA_V1_34_EXECUTION_ENVELOPE_REVI"
test -d "$ENVROOT" || { echo "BLOCKED: envelope root missing" >&2; exit 2; }

echo "[4/7] Verifying execution envelope integrity"
"$PYTHON_BIN" "$ENVROOT/tools/verify_execution_envelope.py"

RUNTIME_ZIP="$ENVROOT/artifacts/TMT_GALIA_LOCAL_RUNTIME_v1_34_REVH.zip"
RUNTIME_WORK="$WORK/runtime"
mkdir -p "$RUNTIME_WORK"
"$PYTHON_BIN" - "$RUNTIME_ZIP" "$RUNTIME_WORK" <<'PY'
import sys, zipfile
from pathlib import Path
src=Path(sys.argv[1]); dst=Path(sys.argv[2])
with zipfile.ZipFile(src) as z:
    z.extractall(dst)
PY

RUNTIMEROOT="$RUNTIME_WORK/TMT_GALIA_LOCAL_RUNTIME_v1_34_REVH"
test -f "$RUNTIMEROOT/run_v1_34_macos_arm64.sh" || {
  echo "BLOCKED: runtime runner missing" >&2
  exit 2
}

echo "[5/7] Running real MLX gate"
PYTHON_BIN="$PYTHON_BIN" bash "$RUNTIMEROOT/run_v1_34_macos_arm64.sh"

EVIDENCE="$RUNTIMEROOT/evidence/v1_34"
test -d "$EVIDENCE" || { echo "BLOCKED: evidence directory missing" >&2; exit 2; }

echo "[6/7] Verifying returned evidence independently"
INTAKE_OUT="$WORK/v1_34-return-intake.json"
"$PYTHON_BIN" "$ENVROOT/tools/verify_returned_evidence.py" "$EVIDENCE" --output "$INTAKE_OUT"

"$PYTHON_BIN" - "$EVIDENCE" "$INTAKE_OUT" <<'PY'
import json, sys
from pathlib import Path
evidence=Path(sys.argv[1]); intake=Path(sys.argv[2])
r=json.loads(intake.read_text())
assert r["verdict"]=="PASS", r
assert r["classification"]=="REAL_MLX_EVIDENCE_VERIFIED_HASH_LOCKED_RUNTIME_FACTS_BOUND_LOCAL_UNATTESTED", r
print("RETURN_INTAKE_GATE=PASS")
PY

echo "[7/7] Packaging and atomically publishing immutable return bundle"
RETURN_ZIP="$RESULTS/TMT_GALIA_V1_34_REAL_MLX_EVIDENCE.zip"
"$PYTHON_BIN" - "$EVIDENCE" "$INTAKE_OUT" "$RETURN_ZIP" <<'PY'
import hashlib, os, sys, tempfile, zipfile
from pathlib import Path

evidence=Path(sys.argv[1]); intake=Path(sys.argv[2]); out=Path(sys.argv[3])
results=out.parent
manifest=[]
files=sorted([p for p in evidence.iterdir() if p.is_file()])
for p in files:
    manifest.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  evidence/v1_34/{p.name}")
manifest.append(f"{hashlib.sha256(intake.read_bytes()).hexdigest()}  v1_34-return-intake.json")
bundle_manifest="\n".join(manifest)+"\n"

fd, tmp_name = tempfile.mkstemp(prefix=".v1_34-real-mlx-", suffix=".tmp", dir=results)
os.close(fd)
tmp=Path(tmp_name)
try:
    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, arcname=f"evidence/v1_34/{p.name}")
        z.write(intake, arcname="v1_34-return-intake.json")
        z.writestr("BUNDLE_MANIFEST_SHA256.txt", bundle_manifest)

    with zipfile.ZipFile(tmp) as z:
        names=set(z.namelist())
        required={"v1_34-return-intake.json","BUNDLE_MANIFEST_SHA256.txt"}
        if not required.issubset(names):
            raise RuntimeError("staged evidence bundle missing required members")
        bad=z.testzip()
        if bad is not None:
            raise RuntimeError(f"staged evidence bundle CRC failure: {bad}")

    with tmp.open("rb") as f:
        os.fsync(f.fileno())

    if out.exists():
        raise RuntimeError("final evidence bundle unexpectedly exists")
    os.replace(tmp, out)

    try:
        dfd=os.open(results, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass
except Exception:
    try:
        tmp.unlink(missing_ok=True)
    finally:
        raise

print(f"REAL_MLX_EVIDENCE_BUNDLE={out}")
PY

test -f "$RETURN_ZIP" || { echo "BLOCKED: final evidence bundle was not published" >&2; exit 2; }

echo "V1_34_MAC_FULL_CYCLE=PASS"
echo "Return bundle: $RETURN_ZIP"
